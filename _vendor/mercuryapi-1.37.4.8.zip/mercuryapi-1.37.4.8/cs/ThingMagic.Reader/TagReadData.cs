﻿/*
 * Copyright (c) 2023 Novanta, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

using System;

namespace ThingMagic
{
    /// <summary>
    /// Data representing the reading of an RFID tag
    /// </summary>
    public class TagReadData
    {
        #region Static Fields

        private static byte[] _noData = new byte[0];

        #endregion

        #region Fields

        internal TagData _tagData = null;

        /// <summary>
        /// An abstract class which can be extended for specific protocol.
        /// Currently Gen2TagReadData for Gen2 protocol
        /// </summary>
        public ProtocolTagReadData prd;

        /// <summary>
        /// This metaDataFlags field is used to retrieve the metadata information
        /// from the tagreaddata object.
        /// </summary>
        public SerialReader.TagMetadataFlag metaDataFlags;

        internal int _antenna = 0;
        internal int _lqi = 0;
        internal int _frequency = 0;
        internal int _phase = 0;
        internal string _brand_Identifier = null;
        internal GpioPin[] _GPIO = null;
        internal Reader reader = null;
        internal bool isAsyncRead = false;
        internal UInt64 _tagType = 0;

        /// <summary>
        /// Number of times the Tag was read.
        /// </summary>
        public int ReadCount = 0;

        /// <summary>
        /// Time that search started
        /// </summary>
        internal DateTime _baseTime;
        /// <summary>
        /// Time tag was read, in milliseconds since start of search
        /// </summary>
        internal int _readOffset = 0;
        internal byte[] _data = _noData;
        internal byte[] _dataEPCMem = _noData;
        internal byte[] _dataReservedMem = _noData;
        internal byte[] _dataTidMem = _noData;
        internal byte[] _dataUserMem = _noData;
        //Internal variables to hold errors received from module
        internal int _reservedMemError = -1;
        internal int _epcMemError = -1;
        internal int _tidMemError = -1;
        internal int _userMemError = -1;
        /// <summary>
        /// This flag is used to differentiate data is error data or actual data. Data is considered as error when any tag operation fails.
        /// </summary>
        public bool isErrorData = false;
        /// <summary>
        /// This indicates length of data in bits for all modules.
        /// In case of data length not a multiple of 8, data gets padded since it is represented in bytes.
        /// In this case, dataLength tells the actual size of data
        /// </summary>
        public int dataLength = 0;

        #endregion

        #region Properties

        /// <summary>
        /// Read Data Bytes
        /// </summary>
        public byte[] Data
        {
            get { return (byte[])_data.Clone(); }
        }
        
        /// <summary>
        /// Read EPC Bank Data Bytes
        /// </summary>
        public byte[] EPCMemData
        {
            get { return (byte[])_dataEPCMem; }
        }

        /// <summary>
        /// Read Tid Bank Data Bytes
        /// </summary>
        public byte[] TIDMemData
        {
            get { return (byte[])_dataTidMem; }
        }

        /// <summary>
        /// Read User Bank Data Bytes
        /// </summary>
        public byte[] USERMemData
        {
            get { return (byte[])_dataUserMem; }
        }

        /// <summary>
        /// Read Reserved Bank Data Bytes
        /// </summary>
        public byte[] RESERVEDMemData
        {
            get { return (byte[])_dataReservedMem; }
        }

        /// <summary>
        /// [1-based] numeric identifier of antenna that tag was read on
        /// </summary>
        public int Antenna
        {
            get { return _antenna; } 
        }

        /// <summary>
        /// RSSI units
        /// </summary>
        public int Rssi
        {
            get { return _lqi; }
            set { _lqi = value; }
        }

        /// <summary>
        /// EPC of tag
        /// </summary>
        public byte[] Epc
        {
            get { return _tagData.EpcBytes; }
        }

        /// <summary>
        /// EPC of tag, as human-readable string
        /// </summary>
        public string EpcString
        {
            get { return _tagData.EpcString; }
        }

        /// <summary>
        /// Tag that was read
        /// </summary>
        public TagData Tag
        {
            get { return _tagData; }
        }

        /// <summary>
        /// Frequency at which the tag was read.
        /// </summary>
        public int Frequency
        {
            get { return _frequency; }
        }
        /// <summary>
        /// [1-based] numeric identifier of Brand Identifier that tag was read on
        /// </summary>

        public string BRAND_IDENTIFIER
        {
            get { return _brand_Identifier; }
        }

        /// <summary>
        /// Tag Type
        /// </summary>
        public UInt64 TagType
        {
            get { return _tagType; }
        }

        /// <summary>
        /// Time when tag was read
        /// </summary>
        public DateTime Time
        {
            get 
            {
                if (isAsyncRead)
                {
                    return this._baseTime;
                }
                else
                {                    
                    return this._baseTime.AddMilliseconds(this._readOffset);
                };
            }
        }

        /// <summary>
        /// Phase when tag was read
        /// </summary>
        public int Phase
        {
            get { return _phase; }
        }

        /// <summary>
        /// GPIO value when tag was read
        /// </summary>
        public GpioPin[] GPIO
        {
            get { return _GPIO; }
        }

        /// <summary>
        /// Returns Reserved Memory read error
        /// </summary>
        public int ReservedMemError
        {
            get { return _reservedMemError; }
        }

        /// <summary>
        /// Returns EPC Memory read error
        /// </summary>
        public int EpcMemError
        {
            get { return _epcMemError; }
        }

        /// <summary>
        /// Returns TID Memory read error
        /// </summary>
        public int TidMemError
        {
            get { return _tidMemError; }
        }

        /// <summary>
        /// Returns User Memory read error
        /// </summary>
        public int UserMemError
        {
            get { return _userMemError; }
        }

        /// <summary>
        /// Reader when tag was read
        /// </summary>
        public Reader Reader
        {
            get { return reader; }
            set { reader = value; }
        }

        #endregion

        #region ToString

        /// <summary>
        /// Human-readable representation
        /// </summary>
        /// <returns>A string representing the current object</returns>
        public override string ToString()
        {

            return String.Join("", new string[] {
                 "", ("Tag ID:") , (null != _tagData) ? _tagData.EpcString : "null",
                " ", "ant:", this.Antenna.ToString(),
                " ", "count:", this.ReadCount.ToString(),
                " ", "time:", this.Time.ToString("yyyy-MM-dd'T'HH:mm:ss.fffK"),
            });
        }

        #endregion
    }
}